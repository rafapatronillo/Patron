const $ = (id)=>document.getElementById(id);
const logKey='sleepLogs_v2';const cfgKey='sleepCfg_v2';
let notifTimers=[];
function loadCfg(){const c=JSON.parse(localStorage.getItem(cfgKey)||'{}');
if(c.prepTime)$('prepTime').value=c.prepTime;
if(c.relaxTime)$('relaxTime').value=c.relaxTime;
if(c.bedTime)$('bedTime').value=c.bedTime;
if(c.wakeTime)$('wakeTime').value=c.wakeTime;
if(c.days){document.querySelectorAll('.day').forEach(cb=>cb.checked=c.days.includes(parseInt(cb.value)));}}
function saveCfg(){const days=Array.from(document.querySelectorAll('.day')).filter(cb=>cb.checked).map(cb=>parseInt(cb.value));
const c={prepTime:$('prepTime').value,relaxTime:$('relaxTime').value,bedTime:$('bedTime').value,wakeTime:$('wakeTime').value,days};
localStorage.setItem(cfgKey,JSON.stringify(c));$('cfgStatus').textContent='Configurações guardadas.';}
function askNotifications(){Notification.requestPermission().then(p=>{if(p==='granted')$('cfgStatus').textContent='Notificações ativas ✅';});}
function testNotification(){if(Notification.permission==='granted')new Notification('Teste','Está a funcionar ✨');}
function loadLogs(){return JSON.parse(localStorage.getItem(logKey)||'[]');}
function saveLogs(r){localStorage.setItem(logKey,JSON.stringify(r));}
function formatDate(d){return new Date(d).toLocaleDateString();}
function renderTable(){const tb=document.querySelector('#logTable tbody');tb.innerHTML='';const rows=loadLogs().slice(-14).reverse();
for(const r of rows){const tr=document.createElement('tr');
tr.innerHTML=`<td>${formatDate(r.date)}</td><td>${r.duration}</td><td>${r.energy}</td><td>${r.mood}</td><td>${r.notes||''}</td><td><button class="secondary" data-del="${r.id}">X</button></td>`;
tb.appendChild(tr);}tb.querySelectorAll('button[data-del]').forEach(b=>b.addEventListener('click',()=>{const rows=loadLogs().filter(x=>x.id!==b.dataset.del);saveLogs(rows);renderTable();updateCharts();}));}
function addLog(){const r={id:String(Date.now()),date:new Date().toISOString(),duration:$('sleepDuration').value,energy:parseInt($('energy').value),mood:parseInt($('mood').value),notes:$('notes').value.trim()};const rows=loadLogs();rows.push(r);saveLogs(rows);$('logStatus').textContent='Guardado.';renderTable();updateCharts();}
function exportCsv(){const rows=loadLogs();const h=['data','duracao','energia','humor','notas'];const lines=[h.join(',')];rows.forEach(r=>lines.push([formatDate(r.date),r.duration,r.energy,r.mood,'"'+(r.notes||'').replace(/"/g,'""')+'"'].join(',')));const blob=new Blob([lines.join('\n')],{type:'text/csv'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='registos.csv';a.click();URL.revokeObjectURL(url);}
// Charts
let chartSono, chartEH;
function updateCharts(){const rows=loadLogs().slice(-14);
const labels=rows.map(r=>formatDate(r.date));const sono=rows.map(r=>parseFloat(r.duration.split(':')[0])+parseFloat(r.duration.split(':')[1])/60);
const energia=rows.map(r=>r.energy);const humor=rows.map(r=>r.mood);
if(chartSono)chartSono.destroy();if(chartEH)chartEH.destroy();
chartSono=new Chart($('chartSono'),{type:'line',data:{labels,datasets:[{label:'Sono (h)',data:sono,borderColor:'#9D7BD8',backgroundColor:'rgba(157,123,216,0.3)',fill:true,tension:0.3}]},
options:{plugins:{legend:{labels:{color:'#EAE6F2'}}},scales:{x:{ticks:{color:'#EAE6F2'}},y:{ticks:{color:'#EAE6F2'}}}}});
chartEH=new Chart($('chartEnergiaHumor'),{type:'bar',data:{labels,datasets:[{label:'Energia',data:energia,backgroundColor:'#4B8BBE'},{label:'Humor',data:humor,backgroundColor:'#E4C66D'}]},
options:{plugins:{legend:{labels:{color:'#EAE6F2'}}},scales:{x:{ticks:{color:'#EAE6F2'}},y:{ticks:{color:'#EAE6F2',stepSize:1,min:0,max:5}}}}});}
// Dark mode toggle
$('toggleTheme').addEventListener('click',()=>{document.body.classList.toggle('light-mode');});
$('saveCfg').addEventListener('click',saveCfg);$('askNotif').addEventListener('click',askNotifications);
$('testNotif').addEventListener('click',testNotification);$('addLog').addEventListener('click',addLog);$('exportCsv').addEventListener('click',exportCsv);
loadCfg();renderTable();updateCharts();